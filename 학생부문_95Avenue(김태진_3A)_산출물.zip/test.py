# -*- coding: utf-8 -*-
"""
Created on Thu Oct  3 17:43:55 2019

@author: JUNG
"""

import module1

result_list = module1.module1('아이폰xr')
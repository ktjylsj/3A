# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
from app import app
 
app.run(host="127.0.0.1", port=3000)
